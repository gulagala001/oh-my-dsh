import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { EventEmitter } from 'node:events'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import test from 'node:test'
import {
  ChangeLedgerEngine,
  ChangeLedgerError,
  ChangeLedgerService,
  TurnCheckpointCoordinator,
  createRewindHttpHandler,
} from '../lib/index.js'

const execFileAsync = promisify(execFile)

test('bundle registers its service and waits for the released Web host service', async (t) => {
  const storageDir = await mkdtemp(join(tmpdir(), 'dsh-turn-rewind-service-'))
  t.after(() => rm(storageDir, { recursive: true, force: true }))
  const injections = []
  let provided
  const service = new ChangeLedgerService({
    provide(name, value) { provided = { name, value } },
    inject(names) { injections.push(names) },
    logger: { info() {}, warn() {}, error() {} },
  }, { storageDir })

  assert.deepEqual(provided, { name: 'changeLedger', value: service })
  assert.deepEqual(injections, [
    ['agents'],
    ['webServer', 'sessions', 'sessionQuery', 'agents'],
    ['settings'],
  ])
  await service.initialize()
})

async function fixture() {
  const outer = await mkdtemp(join(tmpdir(), 'dsh-turn-rewind-test-'))
  const workspace = join(outer, 'workspace')
  await mkdir(workspace)
  await git(workspace, 'init', '-b', 'main')
  await git(workspace, 'config', 'user.name', 'Turn Rewind Test')
  await git(workspace, 'config', 'user.email', 'turn-rewind@example.invalid')
  await writeFile(join(workspace, 'code.txt'), 'checkpoint\n')
  await git(workspace, 'add', '--all')
  await git(workspace, 'commit', '-m', 'seed')
  const engine = new ChangeLedgerEngine({ storageDir: join(outer, 'state') })
  await engine.initialize()
  return { outer, workspace, engine, cleanup: () => rm(outer, { recursive: true, force: true }) }
}

async function git(cwd, ...args) {
  await execFileAsync('git', ['-C', cwd, ...args], {
    env: { ...process.env, GIT_CONFIG_NOSYSTEM: '1', GIT_TERMINAL_PROMPT: '0' },
  })
}

test('first-step checkpoint stays off the response path but gates the first root tool', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const agent = preStepAgent('session-web', f.workspace, 2, 8)
  const original = f.engine.createTurnCheckpoint.bind(f.engine)
  const captureStarted = Promise.withResolvers()
  const captureRelease = Promise.withResolvers()
  f.engine.createTurnCheckpoint = async (options) => {
    captureStarted.resolve()
    await captureRelease.promise
    return original(options)
  }
  const { coordinator, listener, toolListener } = installedCoordinator(f.engine)
  let turnContinued = false

  const decision = await listener(
    { agent, turn: 2, step: 1, signal: new AbortController().signal },
    async () => {
      turnContinued = true
      return { kind: 'enter', messages: [{ role: 'user', content: 'unchanged' }] }
    },
  )
  await captureStarted.promise

  assert.deepEqual(decision, { kind: 'enter', messages: [{ role: 'user', content: 'unchanged' }] })
  assert.equal(turnContinued, true)
  assert.equal(coordinator.state(agent.id, 2).status, 'pending')

  assert.deepEqual(await toolListener(
    { agent, parent: Symbol('nested-call'), signal: new AbortController().signal },
    async () => ({ nested: true }),
  ), { nested: true })

  let toolContinued = false
  const tool = toolListener(
    { agent, signal: new AbortController().signal },
    async () => { toolContinued = true; return { isError: false } },
  )
  await new Promise(resolve => setTimeout(resolve, 10))
  assert.equal(toolContinued, false)
  captureRelease.resolve()
  assert.deepEqual(await tool, { isError: false })
  assert.equal(toolContinued, true)
  assert.equal((await f.engine.findTurnCheckpoint({
    cwd: f.workspace, sessionId: agent.id, turn: 2,
  }))?.turnStartSeq, 8)
  assert.equal(coordinator.state(agent.id, 2).status, 'missing')
})

test('tool cancellation while waiting is delegated to the runtime cancellation path', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const agent = preStepAgent('session-cancelled-tool', f.workspace, 2, 8)
  const captureStarted = Promise.withResolvers()
  const captureRelease = Promise.withResolvers()
  f.engine.createTurnCheckpoint = async () => {
    captureStarted.resolve()
    await captureRelease.promise
  }
  const { coordinator, listener, toolListener } = installedCoordinator(f.engine)
  const toolController = new AbortController()
  await listener(
    { agent, turn: 2, step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter' }),
  )
  await captureStarted.promise

  let delegated = false
  const canonicalCancellation = {
    content: [{ type: 'text', text: 'Error: tool call aborted before dispatch' }],
    isError: true,
    error: {
      message: 'tool call aborted before dispatch',
      info: { name: 'AbortError', code: 'ABORTED_BEFORE_DISPATCH' },
    },
  }
  const invocation = toolListener(
    { agent, signal: toolController.signal },
    async () => {
      delegated = true
      assert.equal(toolController.signal.aborted, true)
      return canonicalCancellation
    },
  )
  toolController.abort({ code: 'caller-cancelled' })

  assert.deepEqual(await invocation, canonicalCancellation)
  assert.equal(delegated, true)
  captureRelease.resolve()
  await Promise.all(coordinator.captures.values())
})

test('a session without session events never crashes the tool hook', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  // Issue #20: some session lifecycles expose neither `events` nor `snapshotEvents()`.
  const agent = {
    id: 'session-no-events',
    status: 'running',
    session: { id: 'session-no-events', header: { cwd: f.workspace } },
  }
  const warnings = []
  const { coordinator, listener, toolListener } = installedCoordinator(f.engine, warnings)

  let stepped = false
  assert.deepEqual(
    await listener(
      { agent, turn: 1, step: 1, signal: new AbortController().signal },
      async () => { stepped = true; return { kind: 'enter' } },
    ),
    { kind: 'enter' },
  )
  assert.equal(stepped, true)

  await new Promise(resolve => setTimeout(resolve, 10))
  assert.deepEqual(coordinator.state(agent.id, 1), {
    status: 'failed',
    error: 'turn/start is unavailable before the first step',
  })
  assert.ok(warnings.some(warning => warning.includes('checkpoint failed for session-no-events turn 1')))

  let toolRan = false
  assert.deepEqual(
    await toolListener(
      { agent, signal: new AbortController().signal },
      async () => { toolRan = true; return { ok: true } },
    ),
    { ok: true },
  )
  assert.equal(toolRan, true)
})

test('checkpoint capture serializes one worktree and failure never blocks the turn', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const nested = join(f.workspace, 'nested')
  await mkdir(nested)
  const original = f.engine.createTurnCheckpoint.bind(f.engine)
  let active = 0
  let maxActive = 0
  let failedAttempts = 0
  f.engine.createTurnCheckpoint = async (options) => {
    if (options.sessionId === 'session-failed') {
      failedAttempts += 1
      throw new Error('capture failed')
    }
    active += 1
    maxActive = Math.max(maxActive, active)
    try {
      await new Promise(resolve => setTimeout(resolve, 30))
      return await original(options)
    } finally {
      active -= 1
    }
  }
  const warnings = []
  const { coordinator, listener, toolListener } = installedCoordinator(f.engine, warnings)
  const first = preStepAgent('session-one', f.workspace, 1, 1)
  const second = preStepAgent('session-two', nested, 2, 8)
  const failed = preStepAgent('session-failed', f.workspace, 3, 12)
  let continued = 0
  await Promise.all([
    listener({ agent: first, turn: 1, step: 1, signal: new AbortController().signal }, async () => ({ kind: 'enter' })),
    listener({ agent: second, turn: 2, step: 1, signal: new AbortController().signal }, async () => ({ kind: 'enter' })),
    listener({ agent: failed, turn: 3, step: 1, signal: new AbortController().signal }, async () => { continued += 1; return { kind: 'enter' } }),
  ])
  await listener(
    { agent: failed, turn: 3, step: 1, signal: new AbortController().signal },
    async () => { continued += 1; return { kind: 'enter' } },
  )
  await Promise.all([first, second, failed].map(agent => toolListener(
    { agent, signal: new AbortController().signal },
    async () => ({ isError: false }),
  )))

  assert.equal(maxActive, 1)
  assert.equal(failedAttempts, 1)
  assert.equal(continued, 2)
  assert.equal(coordinator.state('session-failed', 3).status, 'failed')
  assert.match(coordinator.state('session-failed', 3).error, /capture failed/)
  assert.equal(warnings.length, 1)
})

test('bounded automatic checkpoint skips are visible and never block the turn', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  f.engine.createTurnCheckpoint = async () => {
    throw new ChangeLedgerError('TURN_CHECKPOINT_TIMEOUT', 'automatic checkpoint exceeded 5 ms')
  }
  const warnings = []
  const { coordinator, listener, toolListener } = installedCoordinator(f.engine, warnings)
  const agent = preStepAgent('session-skipped', f.workspace, 4, 20)
  let continued = false
  await listener(
    { agent, turn: 4, step: 1, signal: new AbortController().signal },
    async () => { continued = true; return { kind: 'enter' } },
  )
  assert.equal(continued, true)
  await toolListener(
    { agent, signal: new AbortController().signal },
    async () => ({ isError: false }),
  )
  assert.equal(coordinator.state(agent.id, 4).status, 'skipped')
  assert.match(coordinator.state(agent.id, 4).reason, /TURN_CHECKPOINT_TIMEOUT/)
  assert.equal(warnings.length, 1)
})

test('the response continues while the first root tool waits for durable skip recording', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  f.engine.createTurnCheckpoint = async () => {
    throw new ChangeLedgerError('TURN_CHECKPOINT_TIMEOUT', 'automatic checkpoint exceeded 5 ms')
  }
  let releasePersistence
  const persistence = new Promise((resolve) => { releasePersistence = resolve })
  let persistenceStarted = false
  let persisted = false
  f.engine.recordTurnCheckpointSkip = async () => {
    persistenceStarted = true
    await persistence
    persisted = true
  }
  const { listener, toolListener } = installedCoordinator(f.engine)
  const agent = preStepAgent('session-skip-durable-gate', f.workspace, 4, 20)
  let continued = false
  await listener(
    { agent, turn: 4, step: 1, signal: new AbortController().signal },
    async () => { continued = true; return { kind: 'enter' } },
  )
  while (!persistenceStarted) await new Promise((resolve) => setTimeout(resolve, 1))
  assert.equal(continued, true)
  let toolContinued = false
  const invocation = toolListener(
    { agent, signal: new AbortController().signal },
    async () => { toolContinued = true; return { isError: false } },
  )
  await new Promise(resolve => setTimeout(resolve, 10))
  assert.equal(toolContinued, false)
  releasePersistence()
  await invocation
  assert.equal(persisted, true)
  assert.equal(toolContinued, true)
})

test('the checkpoint deadline covers coordinator discovery and engine metadata reads', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const bounded = new ChangeLedgerEngine({
    storageDir: join(f.outer, 'coordinator-deadline-state'),
    turnCheckpointMode: 'legacy',
    turnCheckpointTimeoutMs: 300,
  })
  await bounded.initialize()
  bounded.store.listManifests = async () => new Promise(() => {})
  bounded.recordTurnCheckpointSkip = async () => {}
  const { coordinator, listener, toolListener } = installedCoordinator(bounded)
  const agent = preStepAgent('session-coordinator-deadline', f.workspace, 4, 20)
  let continued = false
  await listener(
    { agent, turn: 4, step: 1, signal: new AbortController().signal },
    async () => { continued = true; return { kind: 'enter' } },
  )
  assert.equal(continued, true)
  const startedAt = Date.now()
  await toolListener(
    { agent, signal: new AbortController().signal },
    async () => ({ isError: false }),
  )
  assert.equal(coordinator.state(agent.id, 4).status, 'skipped')
  assert.ok(Date.now() - startedAt < 600)
  await Promise.all(coordinator.captures.values())
})

test('slow durable skip persistence cannot extend the pre-step deadline', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const bounded = new ChangeLedgerEngine({
    storageDir: join(f.outer, 'slow-outcome-state'),
    turnCheckpointMode: 'legacy',
    turnCheckpointTimeoutMs: 100,
  })
  await bounded.initialize()
  bounded.createTurnCheckpoint = async () => {
    throw new ChangeLedgerError('TURN_CHECKPOINT_TIMEOUT', 'automatic checkpoint exceeded 100 ms')
  }
  let persistenceFinished = false
  bounded.recordTurnCheckpointSkip = async () => {
    await new Promise((resolve) => setTimeout(resolve, 450))
    persistenceFinished = true
  }
  const { coordinator, listener, toolListener } = installedCoordinator(bounded)
  const agent = preStepAgent('session-slow-outcome', f.workspace, 4, 20)
  let continued = false
  await listener(
    { agent, turn: 4, step: 1, signal: new AbortController().signal },
    async () => { continued = true; return { kind: 'enter' } },
  )
  assert.equal(continued, true)
  const startedAt = Date.now()
  await toolListener(
    { agent, signal: new AbortController().signal },
    async () => ({ isError: false }),
  )
  assert.equal(coordinator.state(agent.id, 4).status, 'skipped')
  assert.ok(Date.now() - startedAt < 250)
  while (!persistenceFinished) await new Promise((resolve) => setTimeout(resolve, 10))
})

test('durable checkpoint skips remain visible after the coordinator restarts', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  await f.engine.recordTurnCheckpointSkip({
    cwd: f.workspace,
    sessionId: 'session-skipped-persisted',
    turn: 1,
    turnStartSeq: 1,
    reason: '[TURN_CHECKPOINT_DISABLED] automatic turn checkpoints are disabled',
  })
  const handler = handlerFor(f, new Map([
    ['session-skipped-persisted', liveSession('session-skipped-persisted', f.workspace, oneTurnEvents())],
  ]))
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-skipped-persisted&messageSeq=2')
  assert.equal(preview.status, 200)
  assert.equal(preview.body.status, 'skipped')
  assert.match(preview.body.reason, /TURN_CHECKPOINT_DISABLED/)
})

test('HTTP preview mints a message-bound plan and code-only restore applies it', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]))

  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  assert.equal(preview.status, 200)
  assert.equal(preview.body.status, 'ready')
  assert.equal(preview.body.messageSeq, 2)
  assert.equal(preview.body.turnStartSeq, 1)
  assert.equal(preview.body.checkpointId, checkpoint.id)
  assert.equal(preview.body.totalChanges, 1)
  assert.match(preview.body.planId, /^plan_/)

  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'code', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })
  assert.equal(applied.status, 200)
  assert.equal(applied.body.mode, 'code')
  assert.equal(await readFile(join(f.workspace, 'code.txt'), 'utf8'), 'checkpoint\n')
})

test('preview fails closed if files change between inspection and plan creation', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'previewed\n')
  const originalPlan = f.engine.planRestore.bind(f.engine)
  f.engine.planRestore = async (options) => {
    await writeFile(join(f.workspace, 'code.txt'), 'changed during preview\n')
    return originalPlan(options)
  }
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]))

  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  assert.equal(preview.status, 409)
  assert.equal(preview.body.code, 'PLAN_STALE')
})

test('only the opening direct user message of a turn can own rewind', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  const events = oneTurnEvents()
  events.splice(3, 0, { type: 'user/message', seq: 3, data: { source: { kind: 'user' } } })
  events[4] = { ...events[4], seq: 4 }
  events[5] = { ...events[5], seq: 5 }
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, events)],
  ]))

  const steering = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=3')
  assert.equal(steering.status, 404)
  assert.equal(steering.body.code, 'RESTORE_POINT_NOT_FOUND')
})

test('reviewed HEAD and branch changes remain restorable without moving Git history', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'committed later\n')
  await git(f.workspace, 'add', 'code.txt')
  await git(f.workspace, 'commit', '-m', 'later')
  await git(f.workspace, 'switch', '-c', 'topic')
  const headBefore = (await execFileAsync('git', ['-C', f.workspace, 'rev-parse', 'HEAD'])).stdout.trim()
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]))

  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  assert.equal(preview.body.headChanged, true)
  assert.equal(preview.body.checkpointBranch, 'main')
  assert.equal(preview.body.currentBranch, 'topic')
  assert.match(preview.body.planId, /^plan_/)
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'code', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })
  assert.equal(applied.status, 200)
  assert.equal(await readFile(join(f.workspace, 'code.txt'), 'utf8'), 'checkpoint\n')
  assert.equal((await execFileAsync('git', ['-C', f.workspace, 'rev-parse', 'HEAD'])).stdout.trim(), headBefore)
  assert.equal((await execFileAsync('git', ['-C', f.workspace, 'branch', '--show-current'])).stdout.trim(), 'topic')
})

test('Git operation changes stay blocked', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  await writeFile(join(f.workspace, '.git', 'MERGE_HEAD'), '0000000000000000000000000000000000000000\n')
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]))

  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  assert.equal(preview.body.operationChanged, true)
  assert.equal(preview.body.restoreBlocked, true)
  assert.equal(preview.body.planId, undefined)
})

test('any running Agent in the worktree, including the source Session, blocks preview and apply', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-source', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  const sessions = new Map([
    ['session-source', liveSession('session-source', f.workspace, oneTurnEvents())],
  ])
  const sourceAgent = { id: 'session-source', status: 'running', session: sessions.get('session-source') }
  const blocked = handlerFor(f, sessions, { agents: { list: () => [sourceAgent] } })
  const preview = await request(blocked, 'GET', '/turn-rewind?sessionId=session-source&messageSeq=2')
  assert.deepEqual(preview.body.activeSessionIds, ['session-source'])
  assert.equal(preview.body.planId, undefined)

  const open = handlerFor(f, sessions)
  const ready = await request(open, 'GET', '/turn-rewind?sessionId=session-source&messageSeq=2')
  const applyBlocked = await request(handlerFor(f, sessions, { agents: { list: () => [sourceAgent] } }), 'POST', '/turn-rewind', {
    mode: 'code', sessionId: 'session-source', messageSeq: 2, checkpointId: checkpoint.id,
    planId: ready.body.planId, confirmation: ready.body.confirmation,
  })
  assert.equal(applyBlocked.body.code, 'WORKSPACE_IN_USE')
})

test('combined rewind of the first message creates a blank Session after restoring files', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  let createPayload
  const sessions = new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ])
  const handler = handlerFor(f, sessions, {
    apiProxy: { sessions: {
      async create(requestValue) {
        assert.equal(await readFile(join(f.workspace, 'code.txt'), 'utf8'), 'checkpoint\n')
        createPayload = requestValue.payload
        return okSession('session-new')
      },
      async fork() { throw new Error('first message must not fork a completed turn') },
    } },
  })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.status, 200)
  assert.equal(applied.body.sessionId, 'session-new')
  assert.deepEqual(createPayload, { cwd: f.workspace })
})

test('combined rewind of a later message forks at the previous completed turn', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 2, turnStartSeq: 5,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed in turn two\n')
  let forkPayload
  const sessions = new Map([
    ['session-web', liveSession('session-web', f.workspace, twoTurnEvents())],
  ])
  const handler = handlerFor(f, sessions, {
    apiProxy: { sessions: {
      async create() { throw new Error('later messages must fork') },
      async fork(requestValue) { forkPayload = requestValue.payload; return okSession('session-child') },
    } },
  })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=6')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 6, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.body.sessionId, 'session-child')
  assert.deepEqual(forkPayload, { sessionId: 'session-web', atSeq: 4 })
})

test('DSH 0.1.2 carriers restart conversations through sessionController without apiProxy', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 2, turnStartSeq: 5,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed in turn two\n')
  const calls = []
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, twoTurnEvents())],
  ]), {
    apiProxy: undefined,
    sessionController: {
      async create(request) { calls.push(['create', request]); return { sessionId: 'session-created' } },
      async fork(request) { calls.push(['fork', request]); return { sessionId: 'session-child' } },
    },
  })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=6')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 6, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.status, 200)
  assert.equal(applied.body.sessionId, 'session-child')
  assert.deepEqual(calls, [['fork', { sessionId: 'session-web', atSeq: 4 }]])
})

test('sessionController creates the blank Session for a first-message rewind', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  const calls = []
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]), {
    apiProxy: undefined,
    sessionController: {
      async create(request) { calls.push(['create', request]); return { sessionId: 'session-created' } },
      async fork(request) { calls.push(['fork', request]); return { sessionId: 'unexpected' } },
    },
  })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.body.sessionId, 'session-created')
  assert.deepEqual(calls, [['create', { cwd: f.workspace }]])
})

test('first-message restart retains the source workspace association on modern hosts', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const calls = []
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]), {
    apiProxy: undefined,
    workspaceRegistry: { list: () => [
      { id: 'unrelated', sessionIds: ['other-session'] },
      { id: 'source-workspace', sessionIds: ['session-web'] },
    ] },
    sessionController: {
      async create(value) { calls.push(value); return { sessionId: 'session-created' } },
      async fork() { throw new Error('first message must create') },
    },
  })
  const result = await request(handler, 'POST', '/turn-rewind', {
    mode: 'messages', sessionId: 'session-web', messageSeq: 2,
  })
  assert.equal(result.status, 200)
  assert.equal(result.body.sessionId, 'session-created')
  assert.deepEqual(calls, [{ workspaceId: 'source-workspace' }])
})

test('a host exposing neither restart service fails closed with an explained error', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]), { apiProxy: undefined, sessionController: undefined })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.body.code, 'RESTORE_FAILED_ROLLED_BACK')
  assert.equal(await readFile(join(f.workspace, 'code.txt'), 'utf8'), 'changed\n')
})

test('messages-only rewind forks the conversation in a non-Git directory without touching files', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const plain = join(f.outer, 'plain')
  await mkdir(plain)
  await writeFile(join(plain, 'code.txt'), 'untracked change\n')
  const calls = []
  const handler = handlerFor(f, new Map([
    ['session-plain', liveSession('session-plain', plain, oneTurnEvents())],
  ]), {
    apiProxy: undefined,
    sessionController: {
      async create(request) { calls.push(['create', request]); return { sessionId: 'session-child' } },
      async fork(request) { calls.push(['fork', request]); return { sessionId: 'session-child' } },
    },
  })
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'messages', sessionId: 'session-plain', messageSeq: 2,
  })

  assert.equal(applied.status, 200)
  assert.equal(applied.body.mode, 'messages')
  assert.equal(applied.body.sessionId, 'session-child')
  assert.deepEqual(calls, [['create', { cwd: plain }]])
  assert.equal(await readFile(join(plain, 'code.txt'), 'utf8'), 'untracked change\n')
})

test('messages-only rewind ignores workspace concurrency because it never writes files', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const sessions = new Map([
    ['session-source', liveSession('session-source', f.workspace, twoTurnEvents())],
  ])
  const sourceAgent = { id: 'session-source', status: 'running', session: sessions.get('session-source') }
  let forked
  const handler = handlerFor(f, sessions, {
    agents: { list: () => [sourceAgent] },
    apiProxy: undefined,
    sessionController: {
      async create() { throw new Error('later messages must fork') },
      async fork(request) { forked = request; return { sessionId: 'session-child' } },
    },
  })
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'messages', sessionId: 'session-source', messageSeq: 6,
  })

  assert.equal(applied.status, 200)
  assert.equal(applied.body.sessionId, 'session-child')
  assert.deepEqual(forked, { sessionId: 'session-source', atSeq: 4 })
  assert.equal(await readFile(join(f.workspace, 'code.txt'), 'utf8'), 'checkpoint\n')
})

test('an unsupported rewind mode is rejected before any work', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const handler = handlerFor(f, new Map())
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'everything', sessionId: 'session-source', messageSeq: 1,
  })

  assert.equal(applied.body.code, 'INVALID_ARGUMENTS')
  assert.match(applied.body.error, /mode must be "code", "both", or "messages"/)
})

test('file changes after preview invalidate the restore plan before any conversation is created', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'previewed\n')
  let conversationCreated = false
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]), {
    apiProxy: { sessions: {
      async create() { conversationCreated = true; return okSession('unexpected') },
      async fork() { conversationCreated = true; return okSession('unexpected') },
    } },
  })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  await writeFile(join(f.workspace, 'code.txt'), 'changed again\n')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.body.code, 'PLAN_STALE')
  assert.equal(conversationCreated, false)
})

test('combined rewind compensates restored files when conversation creation fails', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]), {
    apiProxy: { sessions: {
      async create() { return failedSession('create failed') },
      async fork() { throw new Error('unexpected fork') },
    } },
  })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.body.code, 'RESTORE_FAILED_ROLLED_BACK')
  assert.equal(await readFile(join(f.workspace, 'code.txt'), 'utf8'), 'changed\n')
})

test('a no-op checkpoint never degrades into conversation branching', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  let created = false
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]), {
    apiProxy: { sessions: {
      async create() { created = true; return okSession('unexpected') },
      async fork() { created = true; return okSession('unexpected') },
    } },
  })
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  assert.equal(preview.body.totalChanges, 0)
  assert.equal(preview.body.planId, undefined)
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-web', messageSeq: 2, checkpointId: checkpoint.id,
  })
  assert.equal(applied.body.code, 'NO_CHANGES')
  assert.equal(created, false)
})

test('preview is paged while details can retrieve the complete file list', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-web', turn: 1, turnStartSeq: 1,
  })
  for (let index = 0; index < 12; index += 1) {
    await writeFile(join(f.workspace, `later-${String(index).padStart(2, '0')}.txt`), 'later\n')
  }
  const handler = handlerFor(f, new Map([
    ['session-web', liveSession('session-web', f.workspace, oneTurnEvents())],
  ]))
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2')
  assert.equal(preview.body.totalChanges, 12)
  assert.equal(preview.body.changes.length, 8)
  assert.equal(preview.body.truncated, true)
  const details = await request(handler, 'GET', '/turn-rewind?sessionId=session-web&messageSeq=2&details=1&offset=8&limit=200')
  assert.equal(details.body.changes.length, 4)
  assert.equal(details.body.truncated, false)
  assert.equal(details.body.planId, undefined)
})

test('child checkpoints win, sibling checkpoints do not leak, and inherited messages respect seedLength', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const parentPoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'parent', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'sibling snapshot\n')
  const siblingPoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'sibling-a', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'child snapshot\n')
  const childPoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'child', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'current\n')
  const events = oneTurnEvents()
  const sessions = new Map([
    ['parent', liveSession('parent', f.workspace, events)],
    ['child', liveSession('child', f.workspace, events, { parentSession: 'parent', seedLength: 5 })],
    ['sibling-a', liveSession('sibling-a', f.workspace, events, { parentSession: 'parent', seedLength: 5 })],
    ['sibling-b', liveSession('sibling-b', f.workspace, events, { parentSession: 'parent', seedLength: 5 })],
    ['cutoff', liveSession('cutoff', f.workspace, events, { parentSession: 'parent', seedLength: 2 })],
  ])
  const handler = handlerFor(f, sessions)

  assert.equal((await request(handler, 'GET', '/turn-rewind?sessionId=child&messageSeq=2')).body.checkpointId, childPoint.id)
  assert.equal((await request(handler, 'GET', '/turn-rewind?sessionId=sibling-a&messageSeq=2')).body.checkpointId, siblingPoint.id)
  assert.equal((await request(handler, 'GET', '/turn-rewind?sessionId=sibling-b&messageSeq=2')).body.checkpointId, parentPoint.id)
  assert.equal((await request(handler, 'GET', '/turn-rewind?sessionId=cutoff&messageSeq=2')).body.status, 'missing')
})

test('a root session stays rewindable when 0.1.5 reports inheritedEventCount 0', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const point = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'root-015', turn: 1, turnStartSeq: 1,
  })
  // DSH 0.1.5 deleted header.seedLength and reports the inherited prefix as
  // `inheritedEventCount` — 0, never undefined, for a session with no parent. Treating
  // a defined 0 as lineage metadata would invert the fork guard and reject every
  // unforked session with PLAN_STALE.
  const handler = handlerFor(f, new Map([
    ['root-015', liveSession('root-015', f.workspace, oneTurnEvents(), {}, 0)],
  ]))

  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=root-015&messageSeq=2')
  assert.equal(preview.status, 200)
  assert.equal(preview.body.status, 'ready')
  assert.equal(preview.body.checkpointId, point.id)
})

test('a forked 0.1.5 session resolves the parent checkpoint through inheritedEventCount', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const parentPoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'parent-015', turn: 1, turnStartSeq: 1,
  })
  const childPoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'child-015', turn: 2, turnStartSeq: 5,
  })
  const events = twoTurnEvents()
  // No seedLength anywhere: 0.1.5 rejects a stored header that still carries the field.
  const handler = handlerFor(f, new Map([
    ['child-015', liveSession('child-015', f.workspace, events, { parentSession: 'parent-015' }, 5)],
    ['parent-015', liveSession('parent-015', f.workspace, events, {}, 0)],
  ]))

  // The child owns no checkpoint of its own, so the inherited first turn must come
  // from the parent instead of failing the whole rewind with HTTP 409 PLAN_STALE.
  const inherited = await request(handler, 'GET', '/turn-rewind?sessionId=child-015&messageSeq=2')
  assert.equal(inherited.status, 200)
  assert.equal(inherited.body.status, 'ready')
  assert.equal(inherited.body.checkpointId, parentPoint.id)

  // Turn two starts at the inherited boundary, so it belongs to the child itself.
  const own = await request(handler, 'GET', '/turn-rewind?sessionId=child-015&messageSeq=6')
  assert.equal(own.status, 200)
  assert.equal(own.body.checkpointId, childPoint.id)
})

test('the stored session snapshot carries inheritedEventCount into the lineage walk', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const point = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'stored-root', turn: 1, turnStartSeq: 1,
  })
  const events = oneTurnEvents()
  const stored = new Map([
    // Exactly what @deepseek-ai/dsh-session-query returns in 0.1.5: the header has no
    // seedLength and the inherited prefix rides beside it on the snapshot.
    ['stored-leaf', { session: { cwd: f.workspace, parentSession: 'stored-root' }, events, inheritedEventCount: 5 }],
    ['stored-root', { session: { cwd: f.workspace }, events, inheritedEventCount: 0 }],
  ])
  const handler = createRewindHttpHandler({
    sessions: { get: () => undefined },
    sessionQuery: { readSession: async id => stored.get(id) ?? Promise.reject(new Error(`missing ${id}`)) },
    apiProxy: defaultApiProxy(),
  }, f.engine, new TurnCheckpointCoordinator(f.engine))

  const inherited = await request(handler, 'GET', '/turn-rewind?sessionId=stored-leaf&messageSeq=2')
  assert.equal(inherited.status, 200)
  assert.equal(inherited.body.checkpointId, point.id)
})

test('a declared parent without any inherited-prefix datum still fails closed', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'parent-015', turn: 1, turnStartSeq: 1,
  })
  const handler = handlerFor(f, new Map([
    // Neither 0.1.5's inheritedEventCount nor the legacy seedLength: an inconsistent
    // pair must stay a stale plan rather than silently resolving the wrong checkpoint.
    ['broken-015', liveSession('broken-015', f.workspace, oneTurnEvents(), { parentSession: 'parent-015' })],
    ['parent-015', liveSession('parent-015', f.workspace, oneTurnEvents(), {}, 0)],
  ]))

  const broken = await request(handler, 'GET', '/turn-rewind?sessionId=broken-015&messageSeq=2')
  assert.equal(broken.status, 409)
  assert.equal(broken.body.code, 'PLAN_STALE')
})

test('persisted multi-level lineage validates every inherited message boundary and fails closed', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const point = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'root', turn: 1, turnStartSeq: 1,
  })
  const events = oneTurnEvents()
  const stored = new Map([
    ['leaf', { session: { cwd: f.workspace, parentSession: 'middle', seedLength: 5 }, events }],
    ['middle', { session: { cwd: f.workspace, parentSession: 'root', seedLength: 5 }, events }],
    ['root', { session: { cwd: f.workspace }, events }],
  ])
  const handler = createRewindHttpHandler({
    sessions: { get: () => undefined },
    sessionQuery: { readSession: async id => stored.get(id) ?? Promise.reject(new Error(`missing ${id}`)) },
    apiProxy: defaultApiProxy(),
  }, f.engine, new TurnCheckpointCoordinator(f.engine))
  assert.equal((await request(handler, 'GET', '/turn-rewind?sessionId=leaf&messageSeq=2')).body.checkpointId, point.id)

  stored.set('middle', {
    session: { cwd: f.workspace, parentSession: 'root', seedLength: 5 },
    events: events.map(event => event.type === 'turn/start' ? { ...event, seq: 9 } : event),
  })
  const stale = await request(handler, 'GET', '/turn-rewind?sessionId=leaf&messageSeq=2')
  assert.equal(stale.body.code, 'PLAN_STALE')
})

async function request(handler, method, url, body) {
  const requestValue = new EventEmitter()
  requestValue.method = method
  requestValue.url = url
  let status = 0
  let text = ''
  const response = {
    writeHead(value) { status = value },
    end(value = '') { text += value },
  }
  const pending = handler(requestValue, response)
  queueMicrotask(() => {
    if (body !== undefined) requestValue.emit('data', JSON.stringify(body))
    requestValue.emit('end')
  })
  await pending
  return { status, body: JSON.parse(text) }
}

function handlerFor(fixtureValue, sessions, overrides = {}) {
  const ctx = {
    sessions: { get: id => sessions.get(id) },
    sessionQuery: { readSession: async id => {
      const session = sessions.get(id)
      if (session === undefined) throw new Error(`missing ${id}`)
      return { session: session.header, events: session.events }
    } },
    apiProxy: defaultApiProxy(),
    ...overrides,
  }
  // Optional services resolve through the Cordis accessor, never a property read.
  ctx.get = name => ctx[name]
  return createRewindHttpHandler(ctx, fixtureValue.engine, new TurnCheckpointCoordinator(fixtureValue.engine))
}

function defaultApiProxy() {
  return { sessions: {
    async create() { throw new Error('unexpected session.create') },
    async fork() { throw new Error('unexpected session.fork') },
  } }
}

function okSession(sessionId) {
  return { result: { ok: true, value: { sessionId } } }
}

function failedSession(message) {
  return { result: { ok: false, error: { message } } }
}

function liveSession(id, cwd, events, extraHeader = {}, inheritedEventCount) {
  return {
    id,
    header: { cwd, ...extraHeader },
    events,
    ...(inheritedEventCount === undefined ? {} : { inheritedEventCount }),
  }
}

function oneTurnEvents() {
  return [
    { type: 'request/header', seq: 0, data: {} },
    { type: 'turn/start', seq: 1, data: { turn: 1 } },
    { type: 'user/message', seq: 2, data: { source: { kind: 'user' } } },
    { type: 'assistant/message', seq: 3, data: {} },
    { type: 'turn/end', seq: 4, data: { turn: 1 } },
  ]
}

function twoTurnEvents() {
  return [
    ...oneTurnEvents(),
    { type: 'turn/start', seq: 5, data: { turn: 2 } },
    { type: 'user/message', seq: 6, data: { source: { kind: 'user' } } },
    { type: 'assistant/message', seq: 7, data: {} },
    { type: 'turn/end', seq: 8, data: { turn: 2 } },
  ]
}

function preStepAgent(id, cwd, turn, startSeq) {
  return {
    id,
    status: 'running',
    session: { id, header: { cwd }, events: [{ type: 'turn/start', seq: startSeq, data: { turn } }] },
  }
}

function installedCoordinator(engine, warnings = []) {
  let listener
  let toolListener
  const coordinator = new TurnCheckpointCoordinator(engine)
  coordinator.install({
    logger: { warn(value) { warnings.push(value) } },
    on(name, value) {
      if (name === 'agent/pre-step') listener = value
      if (name === 'tools/execute') toolListener = value
      return () => {}
    },
  })
  assert.equal(typeof listener, 'function')
  assert.equal(typeof toolListener, 'function')
  return { coordinator, listener, toolListener }
}

test('HTTP rewind captures and restores an ordinary directory session', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const plain = join(f.outer, 'plain-project')
  await mkdir(join(plain, 'src'), { recursive: true })
  await writeFile(join(plain, 'src/code.txt'), 'checkpoint\n')

  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: plain, sessionId: 'session-plain', turn: 1, turnStartSeq: 1,
  })
  assert.equal(checkpoint.workspaceType, 'directory')
  await writeFile(join(plain, 'src/code.txt'), 'changed\n')
  const handler = handlerFor(f, new Map([
    ['session-plain', liveSession('session-plain', plain, oneTurnEvents())],
  ]))

  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-plain&messageSeq=2')
  assert.equal(preview.status, 200)
  assert.equal(preview.body.status, 'ready')
  assert.equal(preview.body.totalChanges, 1)
  assert.equal(preview.body.currentHead, undefined)
  assert.deepEqual(preview.body.changes.map(change => change.path), ['src/code.txt'])

  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'code', sessionId: 'session-plain', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })
  assert.equal(applied.status, 200)
  assert.equal(applied.body.mode, 'code')
  assert.equal(await readFile(join(plain, 'src/code.txt'), 'utf8'), 'checkpoint\n')
})

test('conversation restart reads optional services through ctx.get, never through property access', async (t) => {
  const f = await fixture()
  t.after(f.cleanup)
  const checkpoint = await f.engine.createTurnCheckpoint({
    cwd: f.workspace, sessionId: 'session-source', turn: 1, turnStartSeq: 1,
  })
  await writeFile(join(f.workspace, 'code.txt'), 'changed\n')
  const sessions = new Map([
    ['session-source', liveSession('session-source', f.workspace, oneTurnEvents())],
  ])
  // The Cordis context proxy throws when a context reads a service property it did
  // not inject; only `get()` may answer with `undefined`.
  const services = {
    sessionController: {
      async create() { return { sessionId: 'session-child' } },
      async fork() { throw new Error('first message must not fork a completed turn') },
    },
  }
  const injected = {
    sessions: { get: id => sessions.get(id) },
    sessionQuery: { readSession: async id => {
      const session = sessions.get(id)
      if (session === undefined) throw new Error(`missing ${id}`)
      return { session: session.header, events: session.events }
    } },
    agents: { list: () => [] },
  }
  const ctx = new Proxy(injected, {
    get(target, property) {
      if (property === 'get') return name => services[name]
      if (Reflect.has(target, property)) return Reflect.get(target, property)
      if (property === 'sessionController' || property === 'apiProxy') {
        throw new Error(`cannot get property "${String(property)}" without inject`)
      }
      return undefined
    },
  })
  const handler = createRewindHttpHandler(ctx, f.engine, new TurnCheckpointCoordinator(f.engine))
  const preview = await request(handler, 'GET', '/turn-rewind?sessionId=session-source&messageSeq=2')
  const applied = await request(handler, 'POST', '/turn-rewind', {
    mode: 'both', sessionId: 'session-source', messageSeq: 2, checkpointId: checkpoint.id,
    planId: preview.body.planId, confirmation: preview.body.confirmation,
  })

  assert.equal(applied.status, 200)
  assert.equal(applied.body.sessionId, 'session-child')
  assert.equal(await readFile(join(f.workspace, 'code.txt'), 'utf8'), 'checkpoint\n')
})
