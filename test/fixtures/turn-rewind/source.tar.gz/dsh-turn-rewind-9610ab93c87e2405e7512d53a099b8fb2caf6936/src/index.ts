/**
 * DSH Turn Rewind, powered by persistent, inspectable, approval-gated Change Ledger restore points.
 * @module @anionex/dsh-turn-rewind
 */
import { readFileSync } from 'node:fs'
import type { Context } from '@deepseek-ai/cordis'
import { ChangeLedgerEngine } from './engine.js'
import { installManageHttp, installRewindHttp, TurnCheckpointCoordinator } from './rewind-host.js'
import { installTurnRewindSettings, TurnRewindSettingsSchema } from './settings.js'
import type { ChangeLedgerConfig } from './types.js'

export * from './engine.js'
export * from './errors.js'
export * from './rewind-host.js'
export * from './settings.js'
export * from './types.js'

/**
 * Version of the running package.
 *
 * A Profile keeps the previous plugin in memory until DSH restarts, so the
 * loaded version is logged at activation and can be compared with what is on
 * disk in `.../profiles/<name>/node_modules/@anionex/dsh-turn-rewind`.
 * @returns the package version, or `unknown` when the manifest is unreadable.
 */
function pluginVersion(): string {
  try {
    const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')) as { version?: unknown }
    return typeof manifest.version === 'string' ? manifest.version : 'unknown'
  } catch {
    return 'unknown'
  }
}

/** Volatile config values are wrappers in DSH 0.1.7 and plain values on older hosts. */
function unwrapVolatileConfig(config: ChangeLedgerConfig): ChangeLedgerConfig {
  const result: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(config)) {
    result[key] = value !== null && typeof value === 'object' && typeof (value as { get?: unknown }).get === 'function'
      ? (value as { get(): unknown }).get()
      : value
  }
  return result as ChangeLedgerConfig
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    changeLedger: ChangeLedgerService
  }
}

/** Cordis service exposed as `ctx.changeLedger` for other DSH plugins. */
export class ChangeLedgerService {
  /** DSH 0.1.7 projects volatile Config fields into its settings form. */
  static Config = TurnRewindSettingsSchema
  readonly engine: ChangeLedgerEngine

  /** Register the service and startup reconciliation. */
  constructor(ctx: Context, config: ChangeLedgerConfig = {}) {
    const normalized = unwrapVolatileConfig(config)
    ctx.provide('changeLedger', this)
    this.engine = new ChangeLedgerEngine(normalized)
    const checkpoints = new TurnCheckpointCoordinator(this.engine)
    ctx.logger.info(`[turn-rewind] v${pluginVersion()} active; workspace modes: git worktree, ordinary directory`)
    ctx.inject(['agents'], (scope: Context) => { checkpoints.install(scope) })
    // `apiProxy` is deliberately absent: DSH 0.1.2-alpha carriers (DSH Desktop 2.x)
    // provide `sessionController` instead, and the route must exist on both.
    ctx.inject(['webServer', 'sessions', 'sessionQuery', 'agents'], (scope: Context) => {
      installRewindHttp(scope, this.engine, checkpoints)
      installManageHttp(scope, this.engine)
    })
    installTurnRewindSettings(ctx, normalized, this.engine)
    void this.engine.initialize().then((reconciled) => {
      if (reconciled > 0) {
        ctx.logger.warn(`[change-ledger] reconciled ${reconciled} interrupted durable operation(s)`)
      } else {
        ctx.logger.info(`[change-ledger] ready; state=${this.engine.config.storageDir}`)
      }
    }).catch((error: unknown) => {
      ctx.logger.error(`[change-ledger] startup failed: ${error instanceof Error ? error.message : String(error)}`)
    })
  }

  /** Wait for startup reconciliation. */
  initialize(): ReturnType<ChangeLedgerEngine['initialize']> {
    return this.engine.initialize()
  }

  /** Create a user restore point. */
  create(options: Parameters<ChangeLedgerEngine['create']>[0]): ReturnType<ChangeLedgerEngine['create']> {
    return this.engine.create(options)
  }

  /** Capture project files before one turn enters its first Agent step. */
  createTurnCheckpoint(
    options: Parameters<ChangeLedgerEngine['createTurnCheckpoint']>[0],
  ): ReturnType<ChangeLedgerEngine['createTurnCheckpoint']> {
    return this.engine.createTurnCheckpoint(options)
  }

  /** Find the prompt-anchored checkpoint for one session turn. */
  findTurnCheckpoint(
    options: Parameters<ChangeLedgerEngine['findTurnCheckpoint']>[0],
  ): ReturnType<ChangeLedgerEngine['findTurnCheckpoint']> {
    return this.engine.findTurnCheckpoint(options)
  }

  /** List restore points. */
  list(options: Parameters<ChangeLedgerEngine['list']>[0]): ReturnType<ChangeLedgerEngine['list']> {
    return this.engine.list(options)
  }

  /** Compare a restore point with the current worktree. */
  inspect(options: Parameters<ChangeLedgerEngine['inspect']>[0]): ReturnType<ChangeLedgerEngine['inspect']> {
    return this.engine.inspect(options)
  }

  /** Create an expiring restore plan. */
  planRestore(options: Parameters<ChangeLedgerEngine['planRestore']>[0]): ReturnType<ChangeLedgerEngine['planRestore']> {
    return this.engine.planRestore(options)
  }

  /** Apply an exact restore plan after approval. */
  applyRestore(options: Parameters<ChangeLedgerEngine['applyRestore']>[0]): ReturnType<ChangeLedgerEngine['applyRestore']> {
    return this.engine.applyRestore(options)
  }

  /** Delete one restore point and collect unused blobs. */
  delete(options: Parameters<ChangeLedgerEngine['delete']>[0]): ReturnType<ChangeLedgerEngine['delete']> {
    return this.engine.delete(options)
  }

  /** List interrupted restore operations and their rescue points. */
  listRecovery(options: Parameters<ChangeLedgerEngine['listRecovery']>[0]): ReturnType<ChangeLedgerEngine['listRecovery']> {
    return this.engine.listRecovery(options)
  }

  /** Inventory every workspace this storage root has persisted state for. */
  listWorkspaces(options?: Parameters<ChangeLedgerEngine['listWorkspaces']>[0]): ReturnType<ChangeLedgerEngine['listWorkspaces']> {
    return this.engine.listWorkspaces(options)
  }

  /** Delete unprotected restore points recorded for one workspace. */
  purgeWorkspace(options: Parameters<ChangeLedgerEngine['purgeWorkspace']>[0]): ReturnType<ChangeLedgerEngine['purgeWorkspace']> {
    return this.engine.purgeWorkspace(options)
  }

  /** Swap runtime-tunable configuration; the storage root must stay fixed. */
  updateConfig(config: ChangeLedgerConfig): void {
    this.engine.updateConfig(config)
  }
}

export default ChangeLedgerService
