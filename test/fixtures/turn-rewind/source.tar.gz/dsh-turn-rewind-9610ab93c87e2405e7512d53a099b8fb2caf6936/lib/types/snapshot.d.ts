import { type PathCacheEntry } from './path-cache.js';
import type { LedgerStore } from './store.js';
import { type WorkspaceSnapshotSource } from './workspace.js';
import type { CaptureSkip, CaptureTruncation, ResolvedChangeLedgerConfig, SnapshotEntry, WorkspaceChange } from './types.js';
/** One captured tree, optionally persisted into the blob store. */
export interface CapturedTree {
    readonly source: WorkspaceSnapshotSource;
    readonly entries: Readonly<Record<string, SnapshotEntry>>;
    readonly gitEntries?: Readonly<Record<string, SnapshotEntry>>;
    /** Eligible paths this capture could not store; a restore never touches them. */
    readonly skipped: readonly CaptureSkip[];
    readonly skippedCount: number;
    /** Set when a limit stopped the capture before every eligible path was read. */
    readonly truncated?: CaptureTruncation;
    /** True when the recorded skip list is shorter than `skippedCount`. */
    readonly skippedListTruncated: boolean;
    readonly treeHash: string;
    readonly fileCount: number;
    readonly totalBytes: number;
}
/** Capture the current tracked and non-ignored Git working tree. */
export declare function captureTree(options: {
    readonly cwd: string;
    readonly config: ResolvedChangeLedgerConfig;
    readonly store?: LedgerStore;
    readonly gitObjectFormat?: 'sha1' | 'sha256';
    /** Per-path identity cache: an unchanged path is reused instead of re-read. */
    readonly pathCache?: Map<string, PathCacheEntry>;
    readonly signal?: AbortSignal;
}): Promise<CapturedTree>;
/**
 * Capture the complete tree twice and accept it only when both path/content and
 * repository fences agree. This prevents a point from silently mixing files
 * observed at incompatible moments while another process is editing the tree.
 */
export declare function captureStableTree(options: {
    readonly cwd: string;
    readonly config: ResolvedChangeLedgerConfig;
    readonly store?: LedgerStore;
    readonly gitObjectFormat?: 'sha1' | 'sha256';
    /** Per-path identity cache: an unchanged path is reused instead of re-read. */
    readonly pathCache?: Map<string, PathCacheEntry>;
    readonly signal?: AbortSignal;
}): Promise<CapturedTree>;
/** Compute stable path-level differences between two captured trees. */
export declare function diffTrees(before: Readonly<Record<string, SnapshotEntry>>, after: Readonly<Record<string, SnapshotEntry>>, comparisonBefore?: Readonly<Record<string, SnapshotEntry>>, comparisonAfter?: Readonly<Record<string, SnapshotEntry>>): WorkspaceChange[];
/** Return whether two snapshot entries are byte/type/mode equivalent. */
export declare function entriesEqual(left: SnapshotEntry | undefined, right: SnapshotEntry | undefined): boolean;
/** Hash a complete path map into a deterministic tree identity. */
export declare function hashTree(entries: Readonly<Record<string, SnapshotEntry>>): string;
/** Byte-verify one workspace-relative path without following a final symlink. */
export declare function captureSnapshotEntry(root: string, path: string, maxFileBytes: number, signal?: AbortSignal, gitObjectFormat?: 'sha1' | 'sha256'): Promise<SnapshotEntry | undefined>;
