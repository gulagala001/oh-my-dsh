/**
 * Runtime settings surface for Turn Rewind on the DSH web settings page.
 * @module @anionex/dsh-turn-rewind
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type ChangeLedgerEngine } from './engine.js';
import type { ChangeLedgerConfig } from './types.js';
/**
 * Namespace join key shared by the host section and the browser settings card.
 *
 * DSH 0.1.5 removed the `settingsNamespace` helper and made `SettingsNamespace`
 * a compile-time-only brand, so a plain lowercase literal is the entire runtime
 * value — the upstream convention (`const CHAT_SETTINGS_NAMESPACE = 'ui-chat'`).
 * The literal satisfies 0.1.5's registration grammar `/^[a-z][a-z0-9-]*$/` and is
 * the exact key both browser settings transports use.
 */
export declare const TURN_REWIND_SETTINGS_NAMESPACE = "turn-rewind";
/** Every runtime-tunable field of {@link ChangeLedgerConfig}; `storageDir` stays config-layer only. */
export interface TurnRewindSettings {
    /** Maximum user and rescue restore points retained per workspace. */
    maxRestorePoints: number;
    /** Maximum automatic turn checkpoints retained per session. */
    maxTurnCheckpointsPerSession: number;
    /** Maximum number of files in one restore point. */
    maxFiles: number;
    /** Maximum bytes read from one regular file. */
    maxFileBytes: number;
    /** Maximum aggregate regular-file bytes in one restore point. */
    maxSnapshotBytes: number;
    /** Restore-plan lifetime in milliseconds. */
    planTtlMs: number;
    /** Age after which a lock whose owner is gone may be reclaimed. */
    staleLockMs: number;
    /** Automatic turn-checkpoint implementation; `off` records durable skips instead. */
    turnCheckpointMode: 'off' | 'auto' | 'git-native' | 'legacy';
    /** Maximum time one automatic checkpoint may block the first Agent step. */
    turnCheckpointTimeoutMs: number;
    /** Maximum uncached worktree bytes read by one automatic Git-native checkpoint. */
    turnCheckpointMaxNewBytes: number;
    /** Fast trusts fenced Git/stat metadata; strict rereads every eligible path. */
    turnCheckpointTrust: 'fast' | 'strict';
}
/** Shared schema for the legacy settings namespace and DSH 0.1.7 Config form. */
export declare const TurnRewindSettingsSchema: z<TurnRewindSettings>;
/**
 * Register the `turn-rewind` settings namespace and apply its resolved value to the
 * running engine. The composition entry (from `cordis.patch.yml`) is the base layer;
 * the user layer persists through the DSH settings provider. `storageDir` is never
 * carried by the namespace: the storage root must not move while the engine runs.
 *
 * `settings` is an optional service, so the whole wiring stays behind
 * `ctx.inject(['settings'], …)`: a host without a provider keeps running on the
 * composition entry alone.
 */
export declare function installTurnRewindSettings(ctx: Context, config: ChangeLedgerConfig, engine: ChangeLedgerEngine): void;
